import express from "express";
import cors from "cors";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { randomUUID } from "node:crypto";
import { GoogleGenAI } from "@google/genai";

const execFileAsync = promisify(execFile);
const app = express();
app.use(cors());
app.use(express.json({limit:"10mb"}));
const upload = multer({ dest:path.join(os.tmpdir(),"kshorts-upload"), limits:{fileSize: 500*1024*1024} });
const jobs = new Map<string, any>();
const outDir = path.join(os.tmpdir(),"kshorts-output");
fs.mkdirSync(outDir,{recursive:true});

const ai = () => {
  if (!process.env.GEMINI_API_KEY) throw new Error("GEMINI_API_KEY가 설정되지 않았습니다. AI Studio Secrets에서 설정하세요.");
  return new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
};
const ANALYSIS_MODEL = process.env.GEMINI_ANALYSIS_MODEL || "gemini-3.8-flash";
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || "gemini-3.1-flash-image";
const TTS_MODEL = process.env.GEMINI_TTS_MODEL || "gemini-3.8-flash-tts";

function jsonFromText(text:string) {
  const clean = text.replace(/^```json\s*/i,"").replace(/^```\s*/,"").replace(/\s*```$/,"").trim();
  return JSON.parse(clean);
}
function srtTime(sec:number) {
  const ms=Math.max(0,Math.round(sec*1000)), h=Math.floor(ms/3600000), m=Math.floor(ms%3600000/60000), s=Math.floor(ms%60000/1000), x=ms%1000;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")},${String(x).padStart(3,"0")}`;
}
function makeSrt(scenes:any[]) {
  return scenes.map((s,i)=>`${i+1}\n${srtTime(s.start)} --> ${srtTime(s.end)}\n${s.japanese}\n`).join("\n");
}
app.get("/api/health",(_req,res)=>res.json({ok:true, apiKeyConfigured:!!process.env.GEMINI_API_KEY}));

app.post("/api/analyze", upload.single("video"), async (req,res)=>{
  let localPath:string|undefined;
  try {
    if (!req.file) return res.status(400).json({error:"영상 파일을 업로드해 주세요."});
    localPath=req.file.path;
    const mime=req.file.mimetype || "video/mp4";
    const client=ai();
    const file=await client.files.upload({file:localPath, config:{mimeType:mime}});
    let ready:any=file;
    for(let i=0;i<90 && ready.state==="PROCESSING";i++){
      await new Promise(r=>setTimeout(r,2000));
      ready=await client.files.get({name:file.name!});
    }
    if(ready.state==="FAILED") throw new Error("Gemini 영상 파일 처리가 실패했습니다.");
    const prompt = `Analyze this Korean short-form video for a rights-cleared remake. Return ONLY valid JSON with schema:
{"title":"...","durationSeconds":number,"overallStyle":"...","hook":"...","musicMood":"...","scenes":[{"index":1,"start":0,"end":3.5,"visualDescription":"precise visible details","cameraAndComposition":"...","koreanSpeech":"exact audible Korean words, or empty string","onScreenText":"...","japanese":"natural localized Japanese narration/caption","imagePrompt":"original detailed image prompt in English, vertical 9:16, preserve broad composition and mood but do not reproduce protected characters/logos/artwork","transition":"..."}]}
Use 4-12 scenes as appropriate, keep scene timestamps in source order, and ensure all durations add up to the source length. Transcribe Korean as accurately as possible. Do not invent details. Preserve factual claims but flag uncertain audio in the text. Translate faithfully into natural conversational Japanese. The user selected a Japanese female narrator.`;
    const result=await client.interactions.create({
      model:ANALYSIS_MODEL,
      input:[{type:"video",uri:ready.uri,mime_type:ready.mimeType||mime},{type:"text",text:prompt}]
    });
    const analysis=jsonFromText(result.output_text || "");
    if(!Array.isArray(analysis.scenes)||!analysis.scenes.length) throw new Error("장면 분석 결과가 비어 있습니다.");
    const id=randomUUID();
    jobs.set(id,{id,analysis,createdAt:Date.now(),status:"analyzed",assets:[]});
    res.json({jobId:id,analysis});
  } catch(e:any) {
    res.status(500).json({error:e?.message||"분석 중 오류가 발생했습니다."});
  } finally { if(localPath) fs.promises.unlink(localPath).catch(()=>{}); }
});

app.post("/api/generate/:id", async(req,res)=>{
  const job=jobs.get(req.params.id);
  if(!job) return res.status(404).json({error:"작업을 찾을 수 없습니다."});
  try {
    job.status="generating";
    const client=ai();
    const assets=[];
    for(const scene of job.analysis.scenes){
      const prompt=`Create one photorealistic cinematic vertical 9:16 still image for a Japanese short video. ${scene.imagePrompt}. Visual continuity: ${job.analysis.overallStyle}. No text, no captions, no watermark.`;
      const imageResult=await client.models.generateContent({model:IMAGE_MODEL,contents:prompt,config:{responseModalities:["IMAGE"]}});
      const parts=imageResult.candidates?.[0]?.content?.parts||[];
      const img=parts.find((p:any)=>p.inlineData?.data);
      if(!img) throw new Error(`장면 ${scene.index} 이미지 생성 결과가 없습니다.`);
      const filename=`${job.id}-scene-${scene.index}.png`;
      fs.writeFileSync(path.join(outDir,filename),Buffer.from(img.inlineData.data,"base64"));
      assets.push({index:scene.index,image:`/media/${filename}`});
    }
    const narration=job.analysis.scenes.map((s:any)=>s.japanese).join("\n");
    const tts=await client.interactions.create({
      model:TTS_MODEL,
      input:[{type:"user_input",content:[{type:"text",text:`Read in natural Japanese with a warm, clear, friendly female narrator voice. Keep a lively short-video pace, articulate names and numbers carefully. Text:\n${narration}`}]}],
      response_format:{type:"audio"},
      generation_config:{speech_config:[{voice:"Kore"}]}
    });
    if(!tts.output_audio?.data) throw new Error("일본어 음성 생성 결과가 없습니다.");
    const audioName=`${job.id}-voice.wav`;
    fs.writeFileSync(path.join(outDir,audioName),Buffer.from(tts.output_audio.data,"base64"));
    const srtName=`${job.id}.srt`;
    fs.writeFileSync(path.join(outDir,srtName),makeSrt(job.analysis.scenes),"utf8");
    job.assets=assets; job.audio=`/media/${audioName}`; job.srt=`/media/${srtName}`; job.status="assets_ready";
    res.json({assets,audio:job.audio,srt:job.srt});
  } catch(e:any) { job.status="error"; res.status(500).json({error:e?.message||"생성 중 오류가 발생했습니다."}); }
});

app.post("/api/render/:id",async(req,res)=>{
  const job=jobs.get(req.params.id);
  if(!job || job.status!=="assets_ready") return res.status(400).json({error:"이미지와 음성을 먼저 생성해 주세요."});
  try {
    const ffmpeg = (await import("ffmpeg-static")).default;
    if(!ffmpeg) throw new Error("FFmpeg 실행 파일을 찾을 수 없습니다.");
    const work=path.join(outDir,job.id); fs.mkdirSync(work,{recursive:true});
    const listPath=path.join(work,"concat.txt");
    const clips:string[]=[];
    for(const asset of job.assets){
      const scene=job.analysis.scenes.find((s:any)=>s.index===asset.index);
      const img=path.join(outDir,path.basename(asset.image));
      const clip=path.join(work,`scene-${asset.index}.mp4`);
      const duration=Math.max(1,Number(scene.end)-Number(scene.start));
      await execFileAsync(ffmpeg,["-y","-loop","1","-i",img,"-t",String(duration),"-vf","scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,zoompan=z='min(zoom+0.0008,1.08)':d=1:s=1080x1920:fps=30,setsar=1","-r","30","-c:v","libx264","-pix_fmt","yuv420p",clip]);
      clips.push(clip);
    }
    fs.writeFileSync(listPath,clips.map(p=>`file '${p.replace(/'/g,"'\\''")}'`).join("\n"));
    const silent=path.join(work,"silent.mp4");
    await execFileAsync(ffmpeg,["-y","-f","concat","-safe","0","-i",listPath,"-c","copy",silent]);
    const outputName=`${job.id}-japanese-shorts.mp4`, output=path.join(outDir,outputName);
    const audio=path.join(outDir,`${job.id}-voice.wav`);
    const srt=path.join(outDir,`${job.id}.srt`);
    await execFileAsync(ffmpeg,["-y","-i",silent,"-i",audio,"-vf",`subtitles=${srt}:force_style='FontName=Noto Sans CJK JP,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Alignment=2,MarginV=150'`,"-map","0:v:0","-map","1:a:0","-shortest","-c:v","libx264","-preset","veryfast","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-movflags","+faststart",output]);
    job.status="complete"; job.video=`/media/${outputName}`;
    res.json({video:job.video,status:job.status});
  } catch(e:any){ job.status="render_error"; res.status(500).json({error:`렌더링 실패: ${e?.message||e}. FFmpeg/자막 폰트 지원을 확인하세요.`}); }
});

app.use("/media",express.static(outDir));
const clientDist=path.resolve("dist/client");
if(fs.existsSync(clientDist)){app.use(express.static(clientDist));app.get("*",(_req,res)=>res.sendFile(path.join(clientDist,"index.html")));}
const port=Number(process.env.PORT||8080);
app.listen(port,"0.0.0.0",()=>console.log(`K-Shorts to JP Shorts AI listening on ${port}`));
