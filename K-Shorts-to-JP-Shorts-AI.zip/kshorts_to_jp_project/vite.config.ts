import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({ plugins:[react()], root:"client", server:{host:"0.0.0.0", port:5173}, build:{outDir:"../dist/client", emptyOutDir:true} });