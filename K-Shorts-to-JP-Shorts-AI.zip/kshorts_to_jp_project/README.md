# K-Shorts to JP Shorts AI

Google AI Studio Build Mode용 React + Node.js 풀스택 프로젝트 초안입니다.

## AI Studio에서 실행
1. https://aistudio.google.com/ 에서 **Build** 모드로 이동합니다.
2. **Import from GitHub** 또는 프로젝트 ZIP 업로드/파일 추가 기능을 이용해 이 프로젝트를 가져옵니다.
3. AI Studio의 **Secrets**에서 `GEMINI_API_KEY`를 설정합니다. 키를 브라우저 코드에 넣지 마세요.
4. 미리보기에서 업로드 → 분석 → 이미지/음성 생성 → 렌더링 순서로 테스트합니다.
5. 배포하려면 Publish를 선택합니다.

## 로컬 실행
- Node.js 20 이상 권장
- FFmpeg 정적 바이너리는 `ffmpeg-static`이 설치 시 제공합니다.
- `.env.example`을 `.env`로 복사하고 `GEMINI_API_KEY`를 입력합니다.
- `npm install`
- `npm run dev`

## 현재 구현 범위와 제한
- Gemini File API를 통한 동영상 업로드 및 장면 분석.
- 장면별 신규 이미지 생성.
- Gemini TTS를 이용한 일본어 여성 음성 생성(기본 음성 Kore).
- FFmpeg로 9:16 이미지 기반 모션(줌) 영상, 나레이션, SRT 자막 합성.
- 원본 동영상의 장면 전환 및 구성을 참조하지만 원본 프레임을 그대로 복제하지 않습니다.
- 이 초기 버전은 Veo로 각 장면을 실제 움직이는 생성 영상으로 만들지는 않습니다. 장면별 스틸 이미지에 카메라 줌 효과를 적용합니다. Veo API 연결은 모델 접근 권한과 요금 확인 후 별도 추가가 필요합니다.
- `subtitles` 필터를 사용하므로 배포 환경 FFmpeg의 libass 및 일본어 폰트(Noto Sans CJK JP) 지원 여부를 확인하세요.
- TTS 모델, 이미지 모델, 영상 이해 API는 Google 계정의 모델 접근 권한/요금/쿼터에 따라 달라질 수 있습니다.
- 대본 편집 후에는 이미지/음성을 다시 생성해야 수정 내용이 반영됩니다. 프로덕션 버전에서는 장면별 재생성 및 작업 저장소를 추가하세요.
- 장시간 작업을 위한 영구 스토리지, 사용자 인증, 작업 큐, 자동 정리 정책은 프로덕션 배포 전에 보강해야 합니다.

## 권장 모델
- 분석: `gemini-3.8-flash`
- 이미지: `gemini-3.1-flash-image`
- TTS: `gemini-3.8-flash-tts`

모델 명칭과 API 사용법은 배포 시점의 Google 공식 문서를 확인하세요.
